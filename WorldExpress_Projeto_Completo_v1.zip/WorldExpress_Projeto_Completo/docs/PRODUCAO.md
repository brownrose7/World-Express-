# World Express — passagem para produção

## O que já está feito
- App Android (WebView) usando a interface reconstruída.
- API REST inicial.
- Produtos, pedidos, afiliados, campanhas e suporte.
- Painel administrativo inicial.
- Estrutura de pagamento sem recolher PINs ou credenciais bancárias.

## O que precisa de credenciais/contas do proprietário
1. Domínio e hospedagem da API.
2. Base de dados de produção.
3. Conta de comerciante/gateway para pagamentos.
4. Conta WhatsApp Business/API, se quiser automação oficial.
5. Conta Google Play Developer para publicar na Play Store.

## Pagamentos em Angola
O app deve integrar somente depois de o comerciante obter autorização/credenciais do provedor. A UNITEL Money informa que comerciantes podem aderir para receber pagamentos digitais. A EMIS documenta o ecossistema Multicaixa/Express e requisitos de autenticação. Não colocar PIN do cliente dentro do World Express.

## Segurança antes do lançamento
- HTTPS obrigatório.
- Autenticação com sessões/tokens.
- Passwords com hash.
- Validação de pedidos e preços no servidor.
- Backups.
- Logs de auditoria.
- Política de privacidade e termos finais revisados.
- Nunca armazenar PIN de Multicaixa Express, UNITEL Money ou cartão.
