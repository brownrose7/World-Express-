# WORLD EXPRESS — PROJETO COMPLETO v1

Este pacote reúne a reconstrução do aplicativo, a base Android, uma API e um painel administrativo.

## Pastas
- android/ — projeto Android
- backend/ — API REST
- admin/ — painel administrativo
- docs/ — documentação de produção

## Teste da API
Na pasta backend:
npm install
npm start

Depois:
http://localhost:3000/api/health

## Importante
Esta versão é uma base técnica funcional. Para ser um serviço comercial real, é necessário configurar hospedagem, base de dados, autenticação, domínio, contas de pagamento e as credenciais oficiais dos fornecedores.
