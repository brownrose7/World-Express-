const express=require('express');
const cors=require('cors');
const fs=require('fs');
const path=require('path');
const app=express();
app.use(cors());
app.use(express.json({limit:'2mb'}));
const DB=path.join(__dirname,'data.json');
const seed={
  products:[
    {id:1,name:"Sabão Artesanal",price:1500,category:"Higiene e Limpeza",stock:100},
    {id:2,name:"Capa para Celular",price:2500,category:"Capas e Películas",stock:50},
    {id:3,name:"Carregador Turbo",price:3000,category:"Acessórios Eletrônicos",stock:40}
  ],
  orders:[], users:[], affiliates:[], campaigns:[], messages:[]
};
if(!fs.existsSync(DB)) fs.writeFileSync(DB,JSON.stringify(seed,null,2));
const read=()=>JSON.parse(fs.readFileSync(DB));
const write=x=>fs.writeFileSync(DB,JSON.stringify(x,null,2));

app.get('/api/health',(req,res)=>res.json({ok:true,service:"World Express API"}));
app.get('/api/products',(req,res)=>res.json(read().products));
app.post('/api/products',(req,res)=>{const d=read();const p={id:Date.now(),...req.body};d.products.push(p);write(d);res.status(201).json(p)});
app.post('/api/orders',(req,res)=>{const d=read();const o={id:"WE-"+Date.now(),status:"pending",createdAt:new Date().toISOString(),...req.body};d.orders.push(o);write(d);res.status(201).json(o)});
app.get('/api/orders',(req,res)=>res.json(read().orders));
app.post('/api/affiliates',(req,res)=>{const d=read();const a={id:Date.now(),commissionRate:10,status:"active",...req.body};d.affiliates.push(a);write(d);res.status(201).json(a)});
app.get('/api/affiliates',(req,res)=>res.json(read().affiliates));
app.post('/api/campaigns',(req,res)=>{const d=read();const c={id:Date.now(),status:"pending_review",views:0,clicks:0,sales:0,createdAt:new Date().toISOString(),...req.body};d.campaigns.push(c);write(d);res.status(201).json(c)});
app.get('/api/campaigns',(req,res)=>res.json(read().campaigns));
app.post('/api/support',(req,res)=>{const d=read();const m={id:Date.now(),createdAt:new Date().toISOString(),status:"open",...req.body};d.messages.push(m);write(d);res.status(201).json(m)});

// Payment adapter boundary: never collect card PINs/passwords in this API.
// Real Multicaixa Express / Unitel Money credentials and merchant onboarding must be supplied by the provider.
app.post('/api/payments/create',(req,res)=>{
  const {method,orderId,amount}=req.body;
  if(!method||!orderId||!amount) return res.status(400).json({error:"method, orderId e amount são obrigatórios"});
  res.json({status:"awaiting_provider_setup",method,orderId,amount,
    message:"Gateway de pagamento ainda precisa das credenciais/contrato do comerciante."});
});

app.listen(process.env.PORT||3000,()=>console.log("World Express API running"));
