# World Express — versão 1

Esta versão é um protótipo funcional de frontend que pode ser publicado no GitHub Pages.

Inclui:
- Início
- Produtos e carrinho local
- Conta de afiliado
- Marketing/publicidade
- Registo de pedidos de pagamento
- Chat local de demonstração
- Conta do utilizador
- Suporte
- Base para termos/privacidade
- Armazenamento local no navegador

IMPORTANTE:
GitHub Pages/HTML sozinho não consegue oferecer pagamentos reais, autenticação segura, chat entre vários usuários, carteira financeira, upload de vídeos ou monetização real. Para isso será necessário um backend, base de dados, autenticação e integração com provedores de pagamento.

Como instalar:
1. Extraia o ZIP.
2. Entre no seu repositório GitHub.
3. Substitua o index.html antigo por este index.html.
4. Faça commit.
5. Aguarde o GitHub Pages atualizar.
6. Abra o endereço publicado e teste cada botão.

Não apague o seu projeto antigo antes de testar esta versão.
