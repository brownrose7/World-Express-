const products=[
 {id:1,name:"Sabão artesanal",emoji:"🧼",price:1500},
 {id:2,name:"Sabonete",emoji:"🧴",price:1200},
 {id:3,name:"Sabão líquido artesanal",emoji:"🫧",price:2500},
 {id:4,name:"Vasos artesanais",emoji:"🏺",price:5000},
 {id:5,name:"Resina",emoji:"✨",price:4500},
 {id:6,name:"Capas de celular",emoji:"📱",price:3500},
 {id:7,name:"Películas",emoji:"🛡️",price:1500},
 {id:8,name:"Acessórios eletrônicos",emoji:"🔌",price:4000}
];
let cart=JSON.parse(localStorage.getItem("we_cart")||"[]");
const money=n=>new Intl.NumberFormat("pt-AO").format(n)+" Kz";
function save(){localStorage.setItem("we_cart",JSON.stringify(cart));renderCart();document.getElementById("cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0)}
function renderProducts(){document.getElementById("products").innerHTML=products.map(p=>`<article class="product"><div class="emoji">${p.emoji}</div><h3>${p.name}</h3><div class="price">${money(p.price)}</div><button class="btn primary" onclick="addToCart(${p.id})">Adicionar ao carrinho</button></article>`).join("")}
function addToCart(id){const p=products.find(x=>x.id===id);const item=cart.find(x=>x.id===id);item?item.qty++:cart.push({id:p.id,qty:1});save();openCart()}
function renderCart(){const box=document.getElementById("cartItems");if(!box)return;if(!cart.length){box.innerHTML='<div class="empty">O seu carrinho está vazio.</div>';document.getElementById("cartTotal").textContent="0 Kz";return}let total=0;box.innerHTML=cart.map(x=>{const p=products.find(y=>y.id===x.id);total+=p.price*x.qty;return `<div class="cart-row"><div><b>${p.emoji} ${p.name}</b><br><small>${x.qty} × ${money(p.price)}</small></div><button onclick="removeItem(${p.id})">Remover</button></div>`}).join("");document.getElementById("cartTotal").textContent=money(total)}
function removeItem(id){cart=cart.filter(x=>x.id!==id);save()}
function openCart(){document.getElementById("cartDrawer").classList.add("open")}
document.addEventListener("DOMContentLoaded",()=>{renderProducts();save();document.getElementById("menuBtn").onclick=()=>document.getElementById("nav").classList.toggle("show");document.getElementById("closeCart").onclick=()=>document.getElementById("cartDrawer").classList.remove("open");document.getElementById("clearCart").onclick=()=>{cart=[];save()};document.getElementById("checkoutBtn").onclick=()=>{if(!cart.length)return alert("Adicione pelo menos um produto ao carrinho.");let lines=cart.map(x=>{const p=products.find(y=>y.id===x.id);return `${p.name} — ${x.qty} × ${money(p.price)}`});let total=cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.qty,0);let msg=`Olá World Express! Quero fazer este pedido:%0A%0A${encodeURIComponent(lines.join("\n"))}%0A%0ATotal: ${encodeURIComponent(money(total))}`;window.open("https://wa.me/244929309622?text="+msg,"_blank")};document.querySelector(".cart-pill").onclick=openCart});