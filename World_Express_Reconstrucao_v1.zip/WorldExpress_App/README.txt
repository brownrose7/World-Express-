# World Express — Protótipo

Esta é a primeira reconstrução funcional baseada na imagem fornecida.
Inclui:
- Página inicial e catálogo
- Categorias e pesquisa
- Carrinho
- Pedidos e perfil
- Programa de afiliados
- Área de Marketing/Publicidade
- Criação de anúncios (protótipo)
- Estatísticas de campanhas
- Menu lateral e suporte básico

## Como testar
Abra `index.html` no navegador do celular ou computador.

## Próximas etapas
1. Ligar produtos e pedidos a uma base de dados.
2. Implementar login/cadastro.
3. Integrar pagamentos reais usados em Angola.
4. Integrar WhatsApp Business/API.
5. Criar painel administrativo real.
6. Transformar o protótipo em APK Android e, se desejado, versão iOS.
