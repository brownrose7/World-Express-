# World Express — Android

Projeto Android inicial do aplicativo World Express, reconstruído a partir do protótipo fornecido.

### Incluído
- Loja/catálogo
- Categorias e pesquisa
- Carrinho
- Pedidos
- Perfil
- Programa de afiliados (interface)
- Marketing e publicidade (interface)
- Campanhas e estatísticas de demonstração
- Suporte/menu

### Como gerar o APK
Abra esta pasta no Android Studio e escolha **Build > Build APK(s)**.

O projeto ainda é um protótipo local: pagamentos, login, banco de dados, chat e campanhas reais precisam de backend e integrações antes de produção.
