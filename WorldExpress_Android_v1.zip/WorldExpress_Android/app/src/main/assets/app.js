const products=[
 {id:1,name:"Sabão Artesanal",price:1500,icon:"🧼",cat:"Higiene e Limpeza"},
 {id:2,name:"Capa para Celular",price:2500,icon:"📱",cat:"Capas e Películas"},
 {id:3,name:"Carregador Turbo",price:3000,icon:"🔌",cat:"Acessórios Eletrônicos"},
 {id:4,name:"Vaso Artesanal",price:4500,icon:"🏺",cat:"Artesanato e Decoração"},
 {id:5,name:"Resina Epóxi",price:6500,icon:"💎",cat:"Resina Epóxi"},
 {id:6,name:"Sabão Líquido",price:2200,icon:"🧴",cat:"Higiene e Limpeza"}
];
let cart=[];

function money(n){return n.toLocaleString("pt-AO")+" Kz"}
function navigate(page){window.scrollTo(0,0); const s=document.getElementById("screen");
 if(page==="home") s.innerHTML=home();
 if(page==="categories") s.innerHTML=categories();
 if(page==="cart") s.innerHTML=cartPage();
 if(page==="orders") s.innerHTML=orders();
 if(page==="profile") s.innerHTML=profile();
 if(page==="marketing") s.innerHTML=marketing();
 updateCart();
}
function home(){return `<section class="hero"><h1>Um mundo de possibilidades!</h1><p>Compre, venda, indique e ganhe com o World Express.</p><button class="btn" onclick="navigate('categories')">Ver produtos</button></section>
<input class="search" placeholder="🔎 Pesquisar produtos..." oninput="filterProducts(this.value)">
<section class="section"><h2>Categorias</h2><div class="cats">
<div class="cat" onclick="filterCat('Higiene e Limpeza')"><span>🧼</span>Higiene</div>
<div class="cat" onclick="filterCat('Artesanato e Decoração')"><span>🏺</span>Artesanato</div>
<div class="cat" onclick="filterCat('Resina Epóxi')"><span>💎</span>Resina</div>
<div class="cat" onclick="filterCat('Capas e Películas')"><span>📱</span>Capas</div>
<div class="cat" onclick="filterCat('Acessórios Eletrônicos')"><span>🔌</span>Acessórios</div>
<div class="cat" onclick="navigate('marketing')"><span>📣</span>Marketing</div>
</div></section>
<section class="section"><div class="row"><h2>Produtos em destaque</h2><button class="add" onclick="navigate('categories')">Ver todos</button></div><div id="productGrid" class="products">${productCards(products.slice(0,4))}</div></section>
<div class="card marketing"><h2>📣 Marketing e Publicidade</h2><p>Promova produtos, crie campanhas e acompanhe resultados.</p><button class="btn" onclick="navigate('marketing')">Abrir Marketing</button></div>`}
function productCards(list){return list.map(p=>`<article class="product"><div class="pic">${p.icon}</div><div class="info"><b>${p.name}</b><p class="small">${p.cat}</p><div class="row"><span class="price">${money(p.price)}</span><button class="add" onclick="add(${p.id})">+ Carrinho</button></div></div></article>`).join("")}
function categories(){return `<section class="section"><h2>Categorias</h2><div class="card">${["Higiene e Limpeza","Artesanato e Decoração","Resina Epóxi","Capas e Películas","Acessórios Eletrônicos"].map(c=>`<div class="menu-item" onclick="filterCat('${c}')"><span>${c}</span><b>›</b></div>`).join("")}</div><div class="section"><h2>Produtos</h2><div id="productGrid" class="products">${productCards(products)}</div></div></section>`}
function filterCat(cat){navigate('categories');setTimeout(()=>{document.getElementById("productGrid").innerHTML=productCards(products.filter(p=>p.cat===cat))},0)}
function filterProducts(q){document.getElementById("productGrid").innerHTML=productCards(products.filter(p=>p.name.toLowerCase().includes(q.toLowerCase())||p.cat.toLowerCase().includes(q.toLowerCase())))}
function add(id){cart.push(products.find(p=>p.id===id));updateCart();showToast("Produto adicionado ao carrinho")}
function updateCart(){document.getElementById("cartCount").textContent=cart.length}
function cartPage(){if(!cart.length)return `<div class="empty"><h2>🛒</h2><p>O seu carrinho está vazio.</p><button class="btn" onclick="navigate('categories')">Comprar agora</button></div>`;let total=cart.reduce((a,p)=>a+p.price,0);return `<section class="section"><h2>Meu Carrinho</h2>${cart.map((p,i)=>`<div class="card row"><span>${p.icon} ${p.name}</span><b>${money(p.price)}</b><button onclick="cart.splice(${i},1);navigate('cart')">🗑️</button></div>`).join("")}<div class="card"><div class="row"><b>Subtotal</b><b>${money(total)}</b></div><div class="row"><span>Entrega</span><span>1.000 Kz</span></div><hr><div class="row"><b>Total</b><b class="price">${money(total+1000)}</b></div><button class="btn" style="width:100%;margin-top:12px" onclick="showToast('Pedido enviado para processamento')">Finalizar Pedido</button></div></section>`}
function orders(){return `<section class="section"><h2>Meus Pedidos</h2><div class="card"><b>#WE-0001</b><p>Sabão Artesanal + Capa para Celular</p><span class="price">Em preparação</span></div><div class="card"><b>#WE-0000</b><p>Pedido entregue</p><span>Concluído ✓</span></div></section>`}
function profile(){return `<section class="section"><div class="card"><h2>👤 Minha Conta</h2><p>Cliente World Express</p><div class="menu-item">Meus Pedidos <b>›</b></div><div class="menu-item">Endereços de Entrega <b>›</b></div><div class="menu-item">Meus Favoritos <b>›</b></div><div class="menu-item" onclick="navigate('marketing')">📣 Marketing e Publicidade <b>›</b></div><div class="menu-item">💬 Chat <b>›</b></div><div class="menu-item">🆘 Suporte <b>›</b></div><div class="menu-item">🔐 Termos e Privacidade <b>›</b></div></div>
<div class="card"><h3>👥 Programa de Afiliados</h3><p>Indique produtos e ganhe comissões.</p><button class="btn" onclick="showToast('Link de afiliado copiado')">Copiar meu link</button></div></section>`}
function marketing(){return `<section class="section"><div class="hero"><h1>📣 Marketing</h1><p>Divulgue produtos e transforme visitantes em clientes.</p><button class="btn" onclick="document.getElementById('adForm').scrollIntoView()">Criar anúncio</button></div>
<div class="stats"><div class="stat"><b>1.248</b>Visualizações</div><div class="stat"><b>86</b>Cliques</div><div class="stat"><b>18</b>Pedidos</div></div>
<div class="card"><h3>📊 Campanha atual</h3><p>Promoção Sabão Artesanal</p><div class="row"><span>Cliques</span><b>86</b></div><div class="row"><span>Vendas</span><b>18</b></div><div class="row"><span>Estado</span><b>Ativa</b></div></div>
<div class="card"><h3>📱 Divulgar</h3><button class="btn" onclick="share('WhatsApp')">WhatsApp</button> <button class="btn" onclick="share('Facebook')">Facebook</button> <button class="btn" onclick="share('Instagram')">Instagram</button></div>
<div id="adForm" class="card form"><h3>➕ Criar novo anúncio</h3><label>Produto</label><select><option>Sabão Artesanal</option><option>Capa para Celular</option><option>Carregador Turbo</option></select><label>Título do anúncio</label><input placeholder="Ex.: Promoção especial">
<label>Descrição</label><textarea rows="3" placeholder="Escreva a mensagem do anúncio"></textarea><label>Orçamento (Kz)</label><input type="number" placeholder="5000"><button class="btn" onclick="showToast('Anúncio criado e enviado para aprovação')">Publicar anúncio</button></div>
<div class="card"><h3>⚙️ Administração</h3><div class="menu-item">Anúncios pendentes <b>3</b></div><div class="menu-item">Campanhas ativas <b>4</b></div><div class="menu-item">Receita de publicidade <b>125.000 Kz</b></div></div></section>`}
function share(where){showToast("Opção de partilha: "+where)}
function showToast(t){let x=document.getElementById("toast");x.textContent=t;x.style.display="block";setTimeout(()=>x.style.display="none",2200)}
function toggleMenu(){let d=document.createElement("div");d.className="side";d.innerHTML=`<div class="drawer"><h2>World Express</h2><span class="link" onclick="navigate('home');this.parentElement.parentElement.remove()">🏠 Início</span><span class="link" onclick="navigate('categories');this.parentElement.parentElement.remove()">🛍️ Produtos</span><span class="link" onclick="navigate('marketing');this.parentElement.parentElement.remove()">📣 Marketing</span><span class="link" onclick="navigate('profile');this.parentElement.parentElement.remove()">👥 Afiliados</span><span class="link" onclick="showToast('Suporte aberto');this.parentElement.parentElement.remove()">🆘 Suporte</span><span class="link" onclick="this.parentElement.parentElement.remove()">✕ Fechar</span></div>`;document.body.appendChild(d)}
navigate('home');